# 🚀 Divine Delivery - GitHub Pages Deployment

## 📁 Struktura souborů

```
nadohled.fun/
├── divinedelivery/
│   └── index.html      ← Divine Delivery web
├── dispecink/
│   └── index.html      ← Kurýrní dashboard
└── (další složky...)
```

## 🌐 URL adresy

| Stránka | URL |
|---------|-----|
| Divine Delivery | https://nadohled.fun/divinedelivery/ |
| Dispečink kurýrů | https://nadohled.fun/dispecink/ |
| Admin panel | https://nadohled.fun/divinedelivery/?admin=1 |

---

## 📦 Instalace

### Možnost 1: ZIP soubor
1. Stáhni `nadohled-github-pages.zip`
2. Rozbal do svého GitHub Pages repozitáře
3. Commitni a pushni

### Možnost 2: Jednotlivé soubory
1. Vytvoř složky `divinedelivery/` a `dispecink/`
2. Zkopíruj `divine-delivery-v14.html` → `divinedelivery/index.html`
3. Zkopíruj `dispecink-v21.html` → `dispecink/index.html`

---

## ⚙️ Telegram Admin Panel

### Přístup:
```
https://nadohled.fun/divinedelivery/?admin=1
```
nebo
```
https://nadohled.fun/divinedelivery/#admin
```

### Heslo: `divine2024`

### Jak nastavit Chat ID:
1. Otevři admin panel (URL výše)
2. Zadej heslo
3. Nech restaurace napsat `/start` botovi @Divinedelivery_bot
4. Klikni "Načíst Chat ID"
5. Přiřaď nalezené chaty k restauracím
6. Klikni "Uložit"

---

## 🔗 Propojení

### Z Divine Delivery do dashboardu:
- V admin panelu je tlačítko "Dispečink kurýrů"

### Z dashboardu do Divine Delivery:
- Kliknutí na logo "Divine Delivery" v headeru

---

## 📱 Telegram Bot

- **Username:** @Divinedelivery_bot
- **Token:** 8570496849:AAF0g5W1b7alHlDDkgr7wVvvcT_2yVMaDLY

### Flow objednávky:
1. Zákazník objedná na Divine Delivery
2. Email → order.divinedeliverycz@gmail.com
3. Telegram → Restaurace (s tlačítky pro čas přípravy)
4. Dashboard → Kurýři vidí objednávku
5. Restaurace vybere čas přípravy
6. Kurýr převezme objednávku

---

## 🛡️ Změna admin hesla

V souboru `divinedelivery/index.html` najdi:
```javascript
var TG_ADMIN_PASSWORD = 'divine2024';
```
A změň na své heslo.

---

## 📊 API Endpointy (Wix backend)

| Endpoint | Popis |
|----------|-------|
| `/activeOrders` | Aktivní objednávky |
| `/submitCollab` | Odeslání kolaborace |
| `/customerOrders` | Objednávky zákazníka |

Backend běží na: `https://www.divinedelivery.cz/_functions/`

---

## ✅ Checklist před spuštěním

- [ ] Nahraj soubory na GitHub Pages
- [ ] Otestuj https://nadohled.fun/divinedelivery/
- [ ] Otestuj https://nadohled.fun/dispecink/
- [ ] Nastav Chat ID pro restaurace v admin panelu
- [ ] Otestuj Telegram notifikace
- [ ] Ověř email v Brevo (order.divinedeliverycz@gmail.com)

---

## 🆘 Řešení problémů

### Telegram notifikace nejdou:
1. Zkontroluj že bot token je správný
2. Zkontroluj že Chat ID jsou nastavené
3. Použij "Test" tlačítko v admin panelu

### Admin panel se nezobrazuje:
1. Přidej `?admin=1` do URL
2. Nebo přidej `#admin` do URL

### Objednávky nejdou do dashboardu:
1. Zkontroluj že Wix backend běží
2. Zkontroluj konzoli prohlížeče pro chyby
